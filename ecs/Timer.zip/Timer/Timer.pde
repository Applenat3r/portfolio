time// Emalee Sorensen | 26 Mar 2026 | Timer
import processing.sound.*;
SoundFile buzzer;
Button btnStart, btnStop, btnReset;
int totalTime = 10;
int startTime = 0;
int timeLeft = 0;
boolean running = false;

void setup() {
  size(500, 500);
  buzzer = new SoundFile(this, "buzzer.mp3");
  btnStart = new Button(150, 80, 100, 30, "Start", color(#A5FFA4), color(60));
  btnStop = new Button(350, 80, 100, 30, "Stop", color(#F52900), color(60));
  btnReset = new Button(250, 400, 100, 30, "Reset", color(#F52900), color(60));
  timeLeft = totalTime;
}

void draw() {
  background(127);

  if (running == true) {
    int elapsed = (millis() - startTime)/1000;
    timeLeft  = totalTime - elapsed;

    if (timeLeft <= 0) {
      timeLeft = 0;
      running = false;
      //play sound
      buzzer.play();
    }
  }
  
  btnStart.display();
  btnStart.hover();
  btnStop.display();
  btnStop.hover();
  btnReset.display();
  btnReset.hover();
  fill(#FF8784);
  rect(width/2, height/2, width-100, 200);
  fill(000);
  textSize(100);
  text(timeLeft, width/2, 200);
  //buzzer.play();
  textSize(20);
  text("by Emalee Sorensen", width/2,480);
}


void mousePressed () {
  if(btnStart.over == true) {
    running = true;
    startTime = millis();
  }
  if(btnReset.over == true) {
    running = false;
    startTime = millis();
  }
  if(btnStop.over == true) {
    running = false;
  }
}
