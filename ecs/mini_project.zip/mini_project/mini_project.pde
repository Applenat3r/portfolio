//Emalee Sorensen | 31 Mar 2026 | Mini Project
int x, y, tx, ty, score;
float tw;
PImage player,target;

void setup() {
  size(500, 500);
  x = width/2;
  y = height/2;
  tx = int(random(20, width-20));
  ty = int(random(20, height-20));
  score = 0;
  tw = 100.0;
  player = loadImage("racecar.png");
  target = loadImage("finishline.png");
}

void draw() {
  background(#F8FFAD);
  //ellipse(x, y, 20, 20);
  imageMode(CENTER);
  image(player,x,y);
  scorePanel();
  target();
}

void scorePanel() {
  fill(#FED876);
  rect(width/2, 15, width, 30);
  fill(0);
  textSize(32);
  text("Score:" + score, 20, 25);
}

void target() {
  float d = dist(x, y, tx, ty);
  println(d);
  println(score);
  rectMode(CENTER);
  image(target,tx,ty, tw, tw);
  if (d<50) {
    score = score + int(tw);;
    tx = int(random(20, width-20));
    ty = int(random(20, height-20));
    tw = 100.0;
  }
  tw = tw - 0.1;
  if(tw <= 10) {
    gameOver();
  }
}

void gameOver() {
  background(0);
  fill(255);
  textAlign(CENTER);
  text("Game Over!",width/2, height/2);
  noLoop();
}

void keyPressed() {
  if (y<0) {
    y = height;
  }
  if (y>height) {
    y = 0;
  }
  if (x<0) {
    x = height;
  }
  if (x>height) {
    x = 0;
  }


  if (key == 'w' || key == 'W') {
    y = y - 20;
  } else if (key == 's' || key == 'S') {
    y = y + 20;
  } else if (key == 'a' || key == 'A') {
    x = x - 20;
  } else if (key == 'd' || key == 'D') {
    x = x + 20;
  }
}
