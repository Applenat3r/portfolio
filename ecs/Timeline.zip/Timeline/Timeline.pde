// Emalee Sorensen
void setup() {
  size(950,400);
}
void draw() {
  background(#6B9DFF);
  drawRef();
  histEvent(65,200,"Jun. 1946", true,"Donald Trump is born in New York City, New York.");
  histEvent(390,200, "May 1964", true, "He went to boarding school in Cornwall-on-Hudson, New York");
  histEvent(570,200, "Apr. 2007", true, "Real estate developer, television personality, and brand manager.");
  histEvent(820,200, "Jun. 2020", true, "Focused on ecomomic recovery during pandemic, judicial appointments, signed the Great American Outdoors Act, providing funding for national parks.");
  histEvent(265,300, "Mar. 1950", false, "Living in Queens, New York with his parents.");
  histEvent(465,300, "Sept. 1970", false, "Was working for his father at Trump management in Queens and Brooklyn managing/renting middle class apartments.");
  histEvent(720,300, "Jul. 2019", false, "Signed USMCA trade agreement, focused on economic deregulation, and tax policy.");
  histEvent(914,300, "Feb. 2026", false, "Restored U.S. control over immigration laws, cut fentanyl trafficking at the southern border by 56%, created more than 1.2 million manufacturing/construction jobs.");
}
void drawRef() {
  textAlign(CENTER);
  textSize(38);
  fill(0);
  text("Timeline",width/2,65);
  textSize(18);
  text("By: Emalee Sorensen",width/2,85);
  strokeWeight(2);
  stroke(#5445FF);
  line(50,250,900,250); // Timeline
  stroke(0);
  line(50,245,50,255); // Left tic
  line(900,245,900,255); // Right tic
  line(450,245,450,255); // middle tic
  line(250,245,250,255); // left 2 tic
  line(650,245,650,255); // right 2 tic
  strokeWeight(2);
  textSize(12);
  text("1946",50,270);
  text("1970",450,270);
  text("1950",250,270);
  text("2017",650,270);
  text("2026",900,270);
}
void histEvent(int x, int y, String title, boolean top, String detail) {
  if(top == true) {
    stroke(0);
    line(x,y,x-15,y+50);
  } else {
    stroke(0);
    line(x,y,x-15,y-50);
  }
  rectMode(CENTER);
  fill(#00A1F5);
  stroke(#6BFAFF);
  rect(x,y,100,30,10);
  fill(0);
  text(title,x,y+5);
  if(mouseX > x-50 && mouseX < x+50 && mouseY > y-15 && mouseY < y+15) {
      text(detail,width/2,350);
    }
  }
